import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
# smtplib 用于邮件的发信动作
import smtplib
# email 用于构建邮件内容
from email.mime.text import MIMEText
import requests
import json
import openpyxl as op
from matplotlib import pyplot as plt
import configparser
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os
import threading
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PyQt5.QtCore import QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from PyQt5.QtCore import QThread, pyqtSignal
import time
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QComboBox, QPushButton, QVBoxLayout, QHBoxLayout, QWidget
from PyQt5.QtWidgets import QComboBox, QPushButton, QVBoxLayout, QHBoxLayout, QWidget
import requests
import json
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QLabel, QGridLayout
import openai
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QPushButton, QComboBox, QDialog, QTextEdit, QLineEdit
from PyQt5.QtCore import QTimer, QThread, pyqtSignal
from datetime import datetime
from PyQt5 import QtCore
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

openai.api_key = ''


# ------------------------------获取配置文件参数------------------------------
def getconfig(config_filename):
    # 配置文件路径
    curpath = os.path.dirname(os.path.realpath(__file__))
    cfgpath = os.path.join(curpath, config_filename)
    # 创建对象
    conf = configparser.ConfigParser()
    # 读取ini文件
    conf.read(cfgpath, encoding="utf-8")
    # 获取所有的section
    sections = conf.sections()
    # 将section中config作为数组内容分传递到items
    items = conf.items('config')
    # 所需参数数值获取
    projectId = items[0][1]
    variAble = items[1][1]
    deviceId = items[2][1]
    APIKey = items[3][1]
    startId = items[4][1]
    excelId = items[5][1]
    sheetId = items[6][1]
    streamHttp = items[7][1]
    pointHttp = items[8][1]
    return [
        projectId, variAble, deviceId, APIKey, startId, excelId, sheetId,
        streamHttp, pointHttp
    ]


# ------------------------------获取onenet设备数据------------------------------
def setconfig(did, api, startid, streamHttp, pointHttp, datastream_id):
    #pid:项目名称,vae:变量名称,did:设备ID,point:数据信息,tit:设备名称,eid:excel名称及路径,sid:sheet名(形参下同)
    # url配置参数
    payload = {'start': startid, 'limit': 6000}
    headers = {'api-key': api}
    # 设备详情API
    url_stream = streamHttp + did
    # 从设备详情信息中取出设备号数据(title)
    Title = requests.get(url_stream, headers=headers)
    temp = str(Title.text)
    Jtemp = json.loads(temp)
    data = Jtemp['data']
    datastreams = data['datastreams']
    for index, values in enumerate(datastreams):
        title = values.get('title', '')
    # 设备历史数据API
    url_point = pointHttp + did + "/datapoints?datastream_id=" + datastream_id
    Point = requests.get(url_point, headers=headers, params=payload)
    # 从设备历史数据中取出数据流中数据信息
    temp = str(Point.text)
    Jtemp = json.loads(temp)
    data = Jtemp['data']
    datastreams = data['datastreams']
    for index, values in enumerate(datastreams):
        point = values.get('datapoints', '')
    return [title, point]


# ------------------------------数据导入excel------------------------------
def writeExcel(pid, vae, did, point, tit, eid, sid):
    # 创建excel表
    ws = op.Workbook()
    # 创建sheet表单
    wb = ws.create_sheet(sid)
    # 表头信息
    wb.cell(row=1, column=1, value='项目名称')
    wb.cell(row=1, column=2, value='设备名称')
    wb.cell(row=1, column=3, value='设备ID')
    wb.cell(row=1, column=4, value='变量名称')
    wb.cell(row=1, column=5, value='最新数据')
    wb.cell(row=1, column=6, value='时间')
    # 计数器，代表行数
    count = 1
    # 循环数据信息，每次循环一个字典，计数+1
    for index, values in enumerate(point):
        count += 1
        # time代表数据信息对应时间'at'，temp代表数据信息'value'
        time = str(values.get('at', ''))
        temp = str(values.get('value', ''))
        # 随循环递增exlce表内容，row代表行，column代表列，value代表要添加的信息
        wb.cell(row=count, column=1, value='项目' + pid)
        wb.cell(row=count, column=2, value='设备' + tit)
        wb.cell(row=count, column=3, value=did)
        wb.cell(row=count, column=4, value=vae)
        wb.cell(row=count, column=5, value=temp)
        wb.cell(row=count, column=6, value=time)
    # 在循环外部保存和关闭工作簿
    ws.save(eid)
    ws.close()


# ------------------------------数据导入折线图------------------------------
def drawPicture(pid, vae, did, point, tit):
    # list_x存储时间信息，list_y存储数据信息
    list_x = []
    list_y = []
    plt.ion()
    for index, values in enumerate(point):
        x_time = str(values.get('at', ''))
        y_temperature = float((values.get('value', '')))
        # 每次循环所获数值，添加到对应列表中
        list_x.append(x_time)
        list_y.append(y_temperature)
        # 清除figure坐标轴
        plt.clf()
        # 防止中文乱码
        plt.rcParams['font.sans-serif'] = ['SimHei']
        # 防止负号不显示
        plt.rcParams['axes.unicode_minus'] = False
        # 传递x和y轴数据，后续参数为格式控制
        plt.plot(list_x,
                 list_y,
                 color="r",
                 marker="o",
                 linestyle="-",
                 alpha=0.5,
                 mfc="c")
        # 设置x和y轴名称
        plt.xlabel("Time")
        plt.ylabel("Temperature")
        # x轴赋值
        dfdate_x = ['%s hour' % i for i in list_x]
        plt.xticks(list_x, dfdate_x, rotation=320)
        # 设置网格线
        plt.grid(color="g", linestyle=":", alpha=0.5)
        # 设置图例
        plt.legend(("Project:" + pid + ", device:" + did + "-" + tit + vae, ))
        # 设置标题
        plt.title("Temperature Sensor",
                  fontdict={
                      'fontsize': 15,
                      'fontweight': 20,
                      'va': 'center'
                  },
                  loc="center")
        plt.pause(0.5)
        plt.ioff()
    plt.show()


# ------------------------------窗口输出信息------------------------------
def configprint(pid, vae, did, point, tit):
    #计数循环，窗口递增输出数据流信息
    count = 1
    print('项目名称' + '\t\t\t' + '设备名称' + '\t\t\t\t' + '设备ID' + '\t\t\t\t\t' +
          '变量名称' + '\t\t\t' + '最新数据' + '\t\t\t\t' + '时间')
    for index, values in enumerate(point):
        count += 1
        time = str(values.get('at', ''))
        temperature = str(values.get('value', ''))
        print(pid + '\t\t\t\t' + tit + '\t\t\t\t' + did + '\t\t\t\t' + vae +
              '\t\t\t\t' + temperature + '\t\t\t\t' + time)


class DataFetcher(QThread):
    data_fetched = pyqtSignal(object)
    data_abnormal = pyqtSignal(str)  # 新增：数据异常信号，传递异常信息

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.datastream_id = None  # 初始化数据流ID

    def run(self):
        for data in self.parent.get_data():
            self.data_fetched.emit(data)
            self.check_data(data)  # 检查是否异常
            time.sleep(1)  # Sleep for 1 second

    def check_data(self, data):
        value = data[1]
        if self.datastream_id == 'temp' and (value < 18 or value > 26):
            self.parent.email_sender.send_warning_email(
                f'Temperature abnormal: {value}')
        elif self.datastream_id == 'humi' and (value < 30 or value > 60):
            self.parent.email_sender.send_warning_email(
                f'Humidity abnormal: {value}')
        elif self.datastream_id == 'light' and (value < 40 or value > 100):
            self.parent.email_sender.send_warning_email(
                f'Light intensity abnormal: {value}')
        elif self.datastream_id == 'Smog' and (value > 30):
            self.parent.email_sender.send_warning_email(
                f'Smog intensity abnormal: {value}')


class EmailSender(QThread):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent

    def run(self):
        try:
            # 发信方的信息：发信邮箱，QQ 邮箱授权码s
            from_addr = ''
            password = ''

            # 收信方邮箱
            to_addr = ''

            # 发信服务器
            smtp_server = 'smtp.qq.com'

            # 创建邮件
            msg = MIMEMultipart()
            msg['From'] = from_addr
            msg['To'] = to_addr
            msg['Subject'] = 'LOT DATA'

            # 添加邮件正文
            msg.attach(MIMEText('Please check your data.', 'plain', 'utf-8'))

            # 指定文件路径
            filepath = 'data.xlsx'
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(filepath, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition',
                            'attachment',
                            filename=os.path.basename(filepath))
            msg.attach(part)

            # 连接到SMTP服务器
            server = smtplib.SMTP(smtp_server)
            # 启用安全连接
            server.starttls()
            # 登录SMTP服务器
            server.login(from_addr, password)
            # 发送邮件
            server.sendmail(from_addr, to_addr, msg.as_string())
            # 断开服务器连接
            server.quit()

            print('Email sent.')

        except Exception as e:
            print('Failed to send email:', str(e))

    def send_warning_email(self, warning_message):
        try:
            from_addr = ''
            password = ''
            to_addr = ''
            smtp_server = 'smtp.qq.com'

            msg = MIMEText(warning_message, 'plain', 'utf-8')
            msg['From'] = from_addr
            msg['To'] = to_addr
            msg['Subject'] = 'Warning: Abnormal Data Detected'

            server = smtplib.SMTP(smtp_server)
            server.starttls()
            server.login(from_addr, password)
            server.sendmail(from_addr, to_addr, msg.as_string())
            server.quit()

            print('Warning email sent.')

        except Exception as e:
            print('Failed to send warning email:', str(e))


class ChatThread(QThread):
    new_response = pyqtSignal(str)

    def __init__(self, question):
        super().__init__()
        self.question = question

    def run(self):
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role":
                    "system",
                    "content":
                    "You are an expert in the field of industrial wireless IoT sensing systems."
                },
                {
                    "role": "user",
                    "content": self.question
                },
            ])
        self.new_response.emit(response['choices'][0]['message']['content'])


class ChatDialog(QDialog):

    def __init__(self):
        super().__init__()

        self.question_edit = QLineEdit(self)
        self.response_edit = QTextEdit(self)
        self.response_edit.setReadOnly(True)

        self.send_button = QPushButton('Send', self)
        self.send_button.clicked.connect(self.send_question)

        layout = QVBoxLayout(self)
        layout.addWidget(self.question_edit)
        layout.addWidget(self.send_button)
        layout.addWidget(self.response_edit)

        self.setLayout(layout)

    def send_question(self):
        question = self.question_edit.text()
        self.question_edit.clear()
        self.response_edit.setText('Waiting for response...')
        self.thread = ChatThread(question)
        self.thread.new_response.connect(self.update_response)
        self.thread.start()

    def update_response(self, response):
        self.response_edit.setText(response)


class MyApp(QWidget):

    def __init__(self):
        super().__init__()

        self.config1 = getconfig('node1.ini')
        self.config2 = getconfig('node2.ini')

        self.data_fetcher = DataFetcher(self)
        self.data_fetcher.data_fetched.connect(self.update_plot)
        self.email_sender = EmailSender()
        self.data_fetcher.data_abnormal.connect(
            self.show_warning)  # 新增：连接数据异常信号到警告显示槽函数
        self.initUI()

        self.data = []  # Store the data here

    def initUI(self):
        self.canvas = MyMplCanvas(self, width=5, height=4, dpi=100)

        self.button1 = QPushButton('Start Drawing', self)
        self.button1.clicked.connect(self.button1_clicked)

        self.button2 = QPushButton('Send Email', self)
        self.button2.clicked.connect(self.button2_clicked)

        self.button3 = QPushButton('Send Data to Onenet', self)
        self.button3.clicked.connect(self.button3_clicked)

        self.combo = QComboBox(self)
        self.combo.addItem("temp")
        self.combo.addItem("humi")
        self.combo.addItem("light")
        self.combo.addItem("Smog")

        self.stop_button = QPushButton('Stop Drawing', self)
        self.stop_button.clicked.connect(self.stop_button_clicked)

        self.clear_button = QPushButton('Clear Data', self)
        self.clear_button.clicked.connect(self.clear_button_clicked)

        self.chat_button = QPushButton('AI for help', self)  # 新增聊天按钮
        self.chat_button.clicked.connect(self.chat_button_clicked)  # 连接到槽函数

        self.configComboBox = QComboBox(self)
        self.configComboBox.addItem("node1")
        self.configComboBox.addItem("node2")

        # Create layout
        layout = QGridLayout(self)

        # Add widgets to the layout
        layout.addWidget(self.canvas, 0, 0, 1,
                         5)  # this makes the canvas span 1 row and 5 columns

        layout.addWidget(self.create_centered_label('Drawing Control'), 1, 0)
        layout.addWidget(self.button1, 2, 0)
        layout.addWidget(self.stop_button, 3, 0)
        layout.addWidget(self.clear_button, 4, 0)

        layout.addWidget(self.create_centered_label('Data Control'), 1, 2)
        layout.addWidget(self.button2, 2, 2)
        layout.addWidget(self.button3, 3, 2)

        layout.addWidget(
            self.create_centered_label(
                'Data Stream Selection and AI assistance'), 1, 4)
        layout.addWidget(self.combo, 3, 4)
        layout.addWidget(self.configComboBox, 2, 4)
        layout.addWidget(self.chat_button, 4, 4)  # 将聊天按钮添加到布局中
        self.setLayout(layout)
        self.setWindowTitle('Industrial Wireless IoT Sensing Systems')
        self.setGeometry(300, 300, 900, 600)
        self.show()

    def button1_clicked(self):
        config_file = self.configComboBox.currentText()
        if config_file == "node1":
            self.config = self.config1
        elif config_file == "node2":
            self.config = self.config2
        self.data_fetcher.config = self.config  # 更新数据获取器的配置
        data_type = self.combo.currentText()  # 获取下拉菜单的当前选择
        self.config[1] = data_type  # 将配置中的 variAble 更新为当前选择
        if not self.data_fetcher.isRunning():
            self.data_fetcher.datastream_id = data_type  # 将线程中的数据流ID更新为当前选择
            self.data_fetcher.start()  # 重新启动线程

    def update_plot(self, data):
        self.data.append(data)
        self.canvas.plot(self.data)

    def button2_clicked(self):
        configSet = setconfig(self.config[2], self.config[3], self.config[4],
                              self.config[7], self.config[8],
                              self.data_fetcher.datastream_id)
        title = configSet[0]  # 设备名称
        point = configSet[1]  # 数据流中数据信息

        writeExcel(self.config[0], self.config[1], self.config[2], point,
                   title, self.config[5], self.config[6])
        self.email_sender.start()

    def button3_clicked(self):
        datastream_id = self.combo.currentText(
        )  # Get the current selected option of QComboBox
        data = {
            "datastreams": [{
                "id":
                datastream_id,
                "datapoints": [
                    {
                        "at": datetime.now().isoformat(
                        ),  # 获取当前的时间并将其格式化为 ISO 8601 格式的时间戳
                        "value": float(value)
                    } for _, value in self.data  # 忽略 self.data 中的原始时间戳
                ]
            }]
        }
        print(data)
        status_code = self.send_data_to_onenet(
            "", "", data)  # Correct way to call the method
        if status_code == 200:
            print("Data has been sent to OneNet successfully.")
        else:
            print("Failed to send data to OneNet.")

    # 停止按钮点击事件处理器
    def stop_button_clicked(self):
        if self.data_fetcher.isRunning():
            self.data_fetcher.terminate()  # 结束数据获取线程

    # 清空按钮点击事件处理器
    def clear_button_clicked(self):
        self.data.clear()  # 清空当前数据
        self.canvas.clear()  # 清空画布
        self.canvas.draw()  # 重新绘制画布

    def chat_button_clicked(self):
        self.dialog = ChatDialog()
        self.dialog.show()

    def get_data(self):
        configSet = setconfig(self.data_fetcher.config[2],
                              self.data_fetcher.config[3],
                              self.data_fetcher.config[4],
                              self.data_fetcher.config[7],
                              self.data_fetcher.config[8],
                              self.data_fetcher.datastream_id)
        point = configSet[1]  # 数据流中数据信息
        print(f"Current data stream: {self.data_fetcher.datastream_id}"
              )  # 打印当前的数据流名称
        for index, values in enumerate(point):
            x_time = str(values.get('at', ''))
            y_temperature = float((values.get('value', '')))
            yield x_time, y_temperature

    def send_data_to_onenet(self, device_id, api_key, data):
        url = f"http://api.heclouds.com/devices/{device_id}/datapoints"
        headers = {"api-key": api_key, "Content-Type": "application/json"}
        response = requests.post(url, headers=headers, data=json.dumps(data))
        print(data)
        return response.status_code

    def show_warning(self, warning_message):
        QMessageBox.warning(self, 'Warning', warning_message, QMessageBox.Ok)

    def create_centered_label(self, text):
        label = QLabel(text)
        label.setStyleSheet(
            "color: blue; font-size: 20px; font-weight: bold"
        )  # Set the text color to red, increase font size and make it bold
        label.setAlignment(QtCore.Qt.AlignCenter)
        return label


class MyMplCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super(MyMplCanvas, self).__init__(fig)
        self.setParent(parent)
        self.toolbar = NavigationToolbar(self, self)

    def plot(self, data):
        self.axes.cla()  # Clear the old plot
        list_x, list_y = zip(*data)
        self.axes.plot(list_x,
                       list_y,
                       color="r",
                       marker="o",
                       linestyle="-",
                       alpha=0.5,
                       mfc="c")
        self.axes.grid(True)
        self.draw()

    def clear(self):
        self.axes.cla()  # Clear the old plot


if __name__ == '__main__':
    app = QApplication(sys.argv)

    ex = MyApp()

    sys.exit(app.exec_())
